package actions;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Aluno;

public class RemoverEstudante {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("alunos");
        EntityManager manager = factory.createEntityManager();
        manager.getTransaction().begin();
        
		Scanner sc = new Scanner(System.in);                                                                                        

        
        System.out.println("\nid a ser removido:  ");
		Long idRemover = sc.nextLong();
		
        Aluno a1 = manager.find(Aluno.class, idRemover);
        manager.remove(a1);
        manager.getTransaction().commit();
        
		System.out.println("O contato de " + a1.getNome() + " Removido com sucesso.");

        manager.close();
        factory.close();
        
    }
}
