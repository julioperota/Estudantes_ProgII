package actions;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.estudante;

public class AtualizaEstudante {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("alunos");
        EntityManager manager = factory.createEntityManager();
        manager.getTransaction().begin();
		Scanner sc = new Scanner(System.in);         
		
    	System.out.println("\nInsira o id que deseja alterar: ");
		Long idAltera = Long.parseLong(sc.nextLine());
		
        estudante a1 = manager.find(estudante.class, idAltera);
          


		String Nome="";
		String Email="";
		String Cpf="";
		String DtNasc="";
		String Natural="";
		String End="";
		
		String nome1 = a1.getNome();
		String email1 = a1.getEmail();
		String cpf1 = a1.getCpf();
		LocalDate DtNasc1 = a1.getDataNascimento();
		String natural1 = a1.getNaturalidade();
		String enderco1 = a1.getEndereco();
		
		String nome1 = nome1;
		String email1= email1; 
		String cpf1= cpf1; 
		LocalDate DtNasc1 = DtNasc1; 
		String natural1=natural1; 
		String enderco1=enderco1;

		
		System.out.println("\n\nAlteraçao de dados:");
		System.out.println("Nome: "+ nome1);
		System.out.println("Nome alterado= sc.nextLine();
	 !=  != "") {
			a1.);
			nov;
		}
	
		
		System.out.println("\nEmail: "+ email1);
		System.out.println("Alteracao de e-mail = sc.nextLine();
		 != n != "") {
			a1.se);
			novoE;
		}
		
		
		System.out.println("\nCPF: "+ cpf1);
		System.out.println("CPF alterado= sc.nextLine();
		 != n != "") {
			a1.);
			nov;
		}
	
		
		System.out.println("\nData Nascimento: "+ DtNasc1);
		System.out.println("Alteracao de data:");
		respostaDataNascimento = sc.nextLine();
		
		if (respostaDataNascimento != null || respostaDataNascimento != "") {
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	        LocalDate dataFormatada = LocalDate.parse(respostaDataNascimento, formatter);
	        a1.setDataNascimento(dataFormatada);
			DtNasc1 = dataFormatada;
		}
		
		
		System.out.println("\nNaturalidade: "+ natural1);
		System.out.println("Alteracao da naturalidade:");
		Natural = sc.nextLine();
		
		if (Natural != null || Natural != "") {
			a1.setNaturalidade(Natural);
			natural1 = Natural;
		}	
		
		
		System.out.println("\nEndereço: "+ enderco1);
		System.out.println("Alteracao de endereco:");
		End = sc.nextLine();				

		if (End != null || End != "") {
			a1.setEndereco(End);
			enderco1 = End;
		}
		
		manager.merge(a1);
		
		System.out.println("\nInformações do estudante foram aatualizadas!: ");					
		System.out.println("\nNome: "+ nome1);
		System.out.println("Email: "+ email1);
		System.out.println("CPF: "+ cpf1);
		System.out.println("Data de Nascimento: "+ DtNasc1);
		System.out.println("Naturalidade: "+ natural1);
		System.out.println("Endereço : "+ enderco1 +"\n");
      
        manager.getTransaction().commit();
        manager.close();
        factory.close();
    }
}
