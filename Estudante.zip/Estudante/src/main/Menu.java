
package main;

import java.sql.SQLException;
import java.util.Scanner;

import actions.AtualizaEstudante;
import actions.BuscaEstudanteAnterior;
import actions.NovoEstudante;
import actions.ListaCompleta;
import actions.RemoverEstudante;


public class Menu {

	public static void main(String[] args) throws SQLException {
		
		int opContinua; 
		opContinua = 1;
		
		do {
			System.out.println("\n\n=======   AGENDA   =======");
			System.out.println("1 – Cadastro");
			System.out.println("2 – Lista pelo ID");
			System.out.println("3 – Pesquisar estudante");
			System.out.println("4 - Atualizar estudante");
			System.out.println("5 - Excluir estudanteAluno");
			System.out.println("6 - fim");
			System.out.println("\nDigite a funçao que deseja: ");
			
			Scanner sc = new Scanner(System.in);
			
			int op = Integer.
					parseInt(sc.nextLine());
			
			switch (op) {
		     case 1:
		    	 NovoEstudante.main(args);
		    	 
		       break;

		     case 2:	
		    	 ListaCompleta.main(args);

				break;
     
		     case 3:		
		    	 BuscaEstudanteAnterior.main(args);

		       break;		
		       
		     case 4:
		    	 AtualizaEstudante.main(args);

		       break;		       
		       
		     case 5:		
				RemoverEstudante.main(args);
				
		       break;			       
		       
		     case 6:
		    	System.out.println("\nDeseja encerrar? Finalize digitando qualquer letra ou 0 para retomar ao menu.");
		    	String return6 = sc.next();
				if (return6.equals("0")) {
					break;	
				}else {
					opContinua = 0;
				}
				
		       break;

		     default:
		    	 System.out.println("\nerro.");
		    	 
		       break;
			}
		}while(opContinua == 1);
		
   	 System.out.println("Ageradecemos  a utlizaçao!");
   	 System.exit(0);
		
	}
	
}
